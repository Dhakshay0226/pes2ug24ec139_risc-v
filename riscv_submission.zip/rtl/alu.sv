module alu (
    input  logic [31:0] a, b,
    input  logic [2:0]  alucontrol,
    output logic [31:0] result,
    output logic        zero
);
    logic [31:0] condinvb, sum;
    logic        v;         // overflow
    logic        isAddSub;  // true when operation is add or subtract

    assign condinvb = alucontrol[0] ? ~b : b;
    assign sum      = a + condinvb + {31'b0, alucontrol[0]};
    assign isAddSub = (~alucontrol[2] & ~alucontrol[1]) |
                      (~alucontrol[1] &  alucontrol[0]);
    assign v        = ~(alucontrol[0] ^ a[31] ^ b[31]) & (a[31] ^ sum[31]) & isAddSub;

    always_comb
        case (alucontrol)
            3'b000:  result = sum;                 // add
            3'b001:  result = sum;                 // subtract
            3'b010:  result = a & b;               // and
            3'b011:  result = a | b;               // or
            3'b100:  result = a ^ b;               // xor
            3'b101:  result = {31'b0, sum[31] ^ v}; // slt
            3'b110:  result = a << b[4:0];         // sll
            3'b111:  result = a >> b[4:0];         // srl
            default: result = 32'b0;
        endcase

    assign zero = (result == 32'b0);
endmodule
